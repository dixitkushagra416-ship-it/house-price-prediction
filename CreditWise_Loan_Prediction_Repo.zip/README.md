# CreditWise — Loan Approval Prediction

A machine-learning classification project that predicts whether a loan application is approved (`Yes`) or rejected (`No`) using applicant, financial, credit, and loan-related features.

> **Disclaimer:** This is an educational ML project, not a production lending system. It must not be used to make real credit decisions. The dataset and results should be independently validated before any real-world use.

## Project overview

The notebook explores a loan-approval dataset, handles missing values, preprocesses numerical and categorical features, trains a Decision Tree classifier, and tunes its pruning parameter with cross-validation.

### Workflow

1. Load and inspect the dataset.
2. Explore missing values and duplicate rows.
3. Perform exploratory data analysis (EDA).
4. Remove rows where the target `Loan_Approved` is missing.
5. Split the data into training and test sets (80/20, stratified).
6. Impute numerical values using the median and categorical values using the most frequent category.
7. One-hot encode categorical features.
8. Train a class-balanced Decision Tree classifier.
9. Tune `ccp_alpha` with 5-fold `GridSearchCV`, using macro F1 as the scoring metric.
10. Evaluate the final model on the held-out test set.

## Dataset

The notebook expects a CSV file named `loan_approval_data.csv` in the project root. That CSV was not included in the uploaded notebook, so add the dataset separately before running the notebook.

The notebook reports 1,000 rows and 20 columns before target-null removal. After dropping rows with missing `Loan_Approved`, 950 rows remain. The target distribution is:

| Class | Count |
|---|---:|
| No | 652 |
| Yes | 298 |

## Test-set results

The saved notebook output reports the following results on a 190-row test set:

| Metric | Result |
|---|---:|
| Accuracy | 96.84% |
| Macro precision | 0.96 |
| Macro recall | 0.97 |
| Macro F1-score | 0.96 |
| 5-fold CV macro F1 (best) | 0.9582 |
| Best `ccp_alpha` | 0.005 |

Per-class test metrics:

| Class | Precision | Recall | F1-score | Support |
|---|---:|---:|---:|---:|
| No | 0.99 | 0.96 | 0.98 | 130 |
| Yes | 0.92 | 0.98 | 0.95 | 60 |

These are the notebook's recorded results, not a guarantee of future performance. Accuracy alone is not enough to validate a lending model; fairness, calibration, leakage checks, robustness, and the cost of false approvals/rejections would need further investigation.

## Visualizations

The plots exported from the notebook are stored in [`assets/plots/`](assets/plots/):

- Loan approval distribution by gender
- Applicant gender distribution
- Education level by gender
- Credit score distribution by loan approval
- Confusion matrix

## Run locally

```bash
git clone <your-repository-url>
cd CreditWise_Loan_Prediction

python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Place `loan_approval_data.csv` in the project root, then open:

```bash
jupyter notebook loan_predictor_final.ipynb
```

## Tech stack

Python · Pandas · Scikit-learn · Matplotlib · Seaborn · Jupyter Notebook

## Repository structure

```text
CreditWise_Loan_Prediction/
├── assets/
│   └── plots/
├── loan_predictor_final.ipynb
├── README.md
├── requirements.txt
└── .gitignore
```

## Future improvements

- Compare Decision Tree with Logistic Regression, Random Forest, and gradient-boosting models.
- Inspect class-wise precision/recall and tune the decision threshold.
- Add ROC-AUC, PR-AUC, and calibration analysis.
- Audit feature leakage and evaluate fairness across relevant groups.
- Add a reproducible training script and model serialization after validation.
